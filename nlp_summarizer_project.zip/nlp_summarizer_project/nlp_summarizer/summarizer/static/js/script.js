function showLoader() {
    document.getElementById('loader').style.display = 'block';
}
