import os
import re
import fitz  # PyMuPDF
from django.shortcuts import render
from django.conf import settings
from .forms import DocumentUploadForm
from transformers import pipeline

# Load summarization model
summarizer = pipeline("summarization", model="facebook/bart-large-cnn")

def extract_clean_text_from_pdf(pdf_file_path):
    doc = fitz.open(pdf_file_path)
    full_text = ""

    for page in doc:
        blocks = page.get_text("blocks")
        blocks.sort(key=lambda b: (b[1], b[0]))  # Sort top-down then left-right

        for block in blocks:
            text = block[4].strip()
            if text:
                full_text += text + "\n"

    # Normalize text spacing
    full_text = re.sub(r'\n{2,}', '\n', full_text)
    full_text = re.sub(r'\s+', ' ', full_text)
    return full_text.strip()

def summarize_text(text):
    max_chunk = 1024
    paragraphs = re.split(r'(?<=[.?!])\s+', text)
    current_chunk = ''
    summary_paragraphs = []

    for para in paragraphs:
        if len(current_chunk) + len(para) <= max_chunk:
            current_chunk += para + ' '
        else:
            result = summarizer(current_chunk.strip(), max_length=150, min_length=40, do_sample=False)
            summary_paragraphs.append(result[0]['summary_text'].strip())
            current_chunk = para + ' '

    if current_chunk:
        result = summarizer(current_chunk.strip(), max_length=150, min_length=40, do_sample=False)
        summary_paragraphs.append(result[0]['summary_text'].strip())

    # Return summary with paragraph breaks
    return "\n\n".join(summary_paragraphs)

def index(request):
    summary = ""
    if request.method == 'POST':
        form = DocumentUploadForm(request.POST, request.FILES)
        if form.is_valid():
            pdf_file = request.FILES['document']
            file_path = os.path.join(settings.MEDIA_ROOT, pdf_file.name)
            with open(file_path, 'wb+') as destination:
                for chunk in pdf_file.chunks():
                    destination.write(chunk)

            extracted_text = extract_clean_text_from_pdf(file_path)
            summary = summarize_text(extracted_text)
    else:
        form = DocumentUploadForm()

    return render(request, 'summarizer/index.html', {'form': form, 'summary': summary})
