import fitz  # PyMuPDF
from .extractive import extractive_summary
from .abstractive import abstractive_summary

def extract_text_from_pdf(file_path):
    doc = fitz.open(file_path)
    text = ""
    for page in doc:
        text += page.get_text()
    return text

def summarize_long_document(file_path):
    full_text = extract_text_from_pdf(file_path)
    extract = extractive_summary(full_text)
    chunks = [extract[i:i+600] for i in range(0, len(extract), 600)]
    abstractive_results = [abstractive_summary(chunk) for chunk in chunks]
    return '<br><br>'.join(abstractive_results)
