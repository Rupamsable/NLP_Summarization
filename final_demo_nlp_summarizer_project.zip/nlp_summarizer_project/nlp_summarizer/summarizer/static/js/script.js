function showLoader() {
    document.getElementById('loader').style.display = 'block';
}

document.addEventListener("DOMContentLoaded", function () {
    const uploadArea = document.getElementById("upload-area");
    const fileInput = uploadArea.querySelector('input[type="file"]');
    const fileInfo = document.getElementById("file-info");
    const fileNameEl = document.getElementById("file-name");
    const fileSizeEl = document.getElementById("file-size");
    const removeFileBtn = document.getElementById("remove-file");
  
    if (uploadArea && fileInput) {
      uploadArea.addEventListener("click", () => fileInput.click());
  
      fileInput.addEventListener("change", () => {
        const file = fileInput.files[0];
        if (file) {
          fileInfo.style.display = "flex";
          fileNameEl.textContent = file.name;
          fileSizeEl.textContent = (file.size / 1024).toFixed(2) + " KB";
        }
      });
  
      removeFileBtn.addEventListener("click", () => {
        fileInput.value = "";
        fileInfo.style.display = "none";
      });
    }
  });