import nltk
nltk.download('punkt_tab')